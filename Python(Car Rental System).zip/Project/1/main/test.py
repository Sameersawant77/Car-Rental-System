import tkinter as tk
from tkinter import *
from tkinter.font import Font
from tkinter import messagebox

root=tk.Tk()
root.geometry("300x300")

root.mainloop()
